package com.carpark.service;

import com.carpark.entity.CarParkingDetail;
import com.carpark.exception.InvalidCarParkingSlotException;
import com.carpark.exception.InvalidParkingDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CarParkingServiceTest {

    @Mock
    CarParkingRepository carParkingRepository;

    CarParkingService carParkingService;
    @BeforeEach
    public void setUp()
    {
        carParkingService = new CarParkingService(carParkingRepository);
    }
    @Test
    public void allocatecarParking_DurationLessThanOne_exception()
    {
        //act
        String carNumber = "A113";
        int parkingDurationInHours = 0;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);
        //assign
        Exception exception = assertThrows(InvalidParkingDurationException.class, ()-> carParkingService.allocateCarParking(carParkingModel));
        //assert
        assertEquals(exception.getMessage(),"Parking duration should be between 1-4 hours");
    }

    @Test
    public void allocateCarParking_DurationGreaterThanFour_exception()
    {
        //act
        String carNumber = "D116";
        int parkingDurationInHours = 10;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);
        //assign
        Exception exception = assertThrows(InvalidParkingDurationException.class,()->carParkingService.allocateCarParking(carParkingModel));
        //assert
        assertEquals(exception.getMessage(),"Parking duration should be between 1-4 hours");
    }

    @Test
    public void allocateCarParking_Successful()
    {
        //act
        String carNumber = "A345";
        int parkingDurationInHours = 2;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);
        //assign
        CarParkingDetail carParkingDetail = carParkingService.allocateCarParking(carParkingModel);
        //assert
        assertEquals(carNumber,carParkingDetail.getCarNumber());
    }

    @Test
    public void reallocateCarParking_DurationLessThanOne_exception()
    {
        //act
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 0;
        //assign
        Exception exception = assertThrows(InvalidParkingDurationException.class,()-> carParkingService.reallocateCarParking(parkingSlotId,parkingDurationInHours));
        //assert
        assertEquals(exception.getMessage(),"Parking duration should be between 1-4 hours");
    }

    @Test
    public void reallocateCarParking_DurationGreaterThanFour_exception()
    {
        //act
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 5;
        //assign
        Exception exception = assertThrows(InvalidParkingDurationException.class,()-> carParkingService.reallocateCarParking(parkingSlotId,parkingDurationInHours));
        //assert
        assertEquals(exception.getMessage(),"Parking duration should be between 1-4 hours");
    }

    @Test
    public void reallocateCarParking_Throws_InvalidSlotId_exception()
    {
        //act
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 2;
        //assign
        Exception exception = assertThrows(InvalidCarParkingSlotException.class,()->carParkingService.reallocateCarParking(parkingSlotId,parkingDurationInHours));
        //assert
        assertEquals(exception.getMessage(),"Slot id not found");
    }

    @Test
    public void reallocateCarParking_Successful()
    {
        //act
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 2;
        //assign
        when(carParkingRepository.findById(parkingSlotId)).thenReturn(new CarParkingDetail("A110",2,LocalDateTime.now()));
        CarParkingDetail carParkingDetail = carParkingService.reallocateCarParking(parkingSlotId,parkingDurationInHours);
        //assert
        assertEquals(carParkingDetail.getParkingDurationInHours(),parkingDurationInHours);
    }

    @Test
    public void deallocateCarParking_throwsInvalidSlotId()
    {
        //act
        String slotId = null;
        //assign
        Exception exception = assertThrows(InvalidCarParkingSlotException.class,()->carParkingService.deallocateCarParking(slotId));
        //assert
        assertEquals(exception.getMessage(),"Slot Id cannot be null or empty");
    }

    @Test
    public void deallocateCarParking_Successful()
    {
        //act
        String carParkingSlotId = "123";
        //assign
        when(carParkingRepository.findById(carParkingSlotId)).thenReturn(new CarParkingDetail("A110",2,LocalDateTime.now()));
        //assert
        assertEquals(carParkingService.deallocateCarParking(carParkingSlotId),true);
    }

}
