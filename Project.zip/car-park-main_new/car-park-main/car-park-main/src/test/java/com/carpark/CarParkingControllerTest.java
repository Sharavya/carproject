package com.carpark;

import com.carpark.controller.CarParkingController;
import com.carpark.entity.CarParkingDetail;
import com.carpark.exception.InvalidParkingDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.service.CarParkingService;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CarParkingController.class)
public class CarParkingControllerTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    Gson gson;

    @MockBean
    CarParkingService carParkingService;

    private final String invalidDurationExceptionMessage = "Parking duration should be between 1-4 hours";
    @Test
    public void allocateCarParking_shouldThrow_DurationLessThanOne_exception() throws Exception
    {
        //Required Request Model
        CarParkingModel carParkingModel =new CarParkingModel("A110",0);
        String carParkingModeljsonString = gson.toJson(carParkingModel);

        //mock service layer
       when(carParkingService.allocateCarParking(any(CarParkingModel.class))).thenThrow(new InvalidParkingDurationException(invalidDurationExceptionMessage));

       mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
               .content(carParkingModeljsonString)
               .contentType(MediaType.APPLICATION_JSON))
               .andExpect(mvcResult -> assertEquals(invalidDurationExceptionMessage,mvcResult.getResolvedException().getMessage()));
    }

    /*@Test
    public void allocateCarParking_shouldReturn_201Created_Successful() throws Exception
    {
        //Required request model
        CarParkingModel carParkingModel = new CarParkingModel("A110",2);
        String carParkingModeljsonString = gson.toJson(carParkingModel);

        //mock service layer - to test behaviour
        when(carParkingService.allocateCarParking(any(CarParkingModel.class))).thenReturn(new CarParkingDetail("A110",2, LocalDateTime.now()));

        mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
                .content(carParkingModeljsonString)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.carNumber").value(carParkingModel.getCarNumber()));
    }*/
}


