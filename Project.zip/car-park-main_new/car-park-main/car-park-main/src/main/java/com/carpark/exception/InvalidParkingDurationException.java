package com.carpark.exception;

public class InvalidParkingDurationException extends RuntimeException {
    public InvalidParkingDurationException(String message) {
        super(message);
    }
}
