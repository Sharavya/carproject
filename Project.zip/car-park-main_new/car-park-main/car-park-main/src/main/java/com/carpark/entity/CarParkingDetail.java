package com.carpark.entity;

import java.time.LocalDateTime;
import java.util.UUID;

public class CarParkingDetail {

    private String carNumber;
    private int parkingDurationInHours;
    private String slotId;
    private LocalDateTime entryTime;

    public CarParkingDetail(String carNumber, int parkingDurationInHours, LocalDateTime entryTime) {
        this.carNumber = carNumber;
        this.parkingDurationInHours = parkingDurationInHours;
        this.slotId = UUID.randomUUID().toString();
        this.entryTime = entryTime;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public int getParkingDurationInHours() {
        return parkingDurationInHours;
    }

    public void setParkingDurationInHours(int parkingDurationInHours) {
        this.parkingDurationInHours = parkingDurationInHours;
    }

    public String getSlotId() {
        return slotId;
    }

    public void setSlotId(String slotId) {
        this.slotId = slotId;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    public void setEntryTime(LocalDateTime entryTime) {
        this.entryTime = entryTime;
    }
}
