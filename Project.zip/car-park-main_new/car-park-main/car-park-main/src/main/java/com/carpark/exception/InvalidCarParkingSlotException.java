package com.carpark.exception;

public class InvalidCarParkingSlotException extends RuntimeException{
    public InvalidCarParkingSlotException(String message) {
        super(message);
    }
}
