package com.java.string;

import javax.xml.soap.SAAJResult;
import java.awt.*;
import java.util.Locale;

public class Test {

    public static void main(String[] args) {
        String str1 = "devOn"; // str is ref variable pointing to string object(address will be stored)
        String str2 = "devOn";

        String str3 = new String("devOn");
        System.out.println(str1==str2); //compares hashcode
        System.out.println(str1.equals(str2)); //compares content

        System.out.println(str1==str3);
        System.out.println(str1.equals(str3));

        str1.toUpperCase(); // everytime when we call behaviour of string a new object will be created
        System.out.println(str1);
        str3.toUpperCase();
        System.out.println(str3);
    }
}
