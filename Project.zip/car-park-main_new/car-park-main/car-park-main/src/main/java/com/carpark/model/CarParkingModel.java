package com.carpark.model;

public class CarParkingModel {
    private String carNumber;
    private int parkingDurationInHours;

    public CarParkingModel(String carNumber, int parkingDurationInHours) {
        this.carNumber = carNumber;
        this.parkingDurationInHours = parkingDurationInHours;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public int getParkingDurationInHours() {
        return parkingDurationInHours;
    }
}
