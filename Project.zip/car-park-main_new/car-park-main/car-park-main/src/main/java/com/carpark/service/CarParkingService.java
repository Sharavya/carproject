package com.carpark.service;

import com.carpark.entity.CarParkingDetail;
import com.carpark.exception.InvalidCarParkingSlotException;
import com.carpark.exception.InvalidParkingDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingRepository;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public class CarParkingService {

    CarParkingRepository carParkingRepository;

    public CarParkingService(CarParkingRepository carParkingRepository) {
        this.carParkingRepository = carParkingRepository;
    }

    public CarParkingDetail allocateCarParking(CarParkingModel carParkingModel) {
        if(carParkingModel.getParkingDurationInHours()<1 || carParkingModel.getParkingDurationInHours()>4)
        {
            throw new InvalidParkingDurationException("Parking duration should be between 1-4 hours");
        }
        CarParkingDetail carParkingDetail = new CarParkingDetail(carParkingModel.getCarNumber(),carParkingModel.getParkingDurationInHours(),
                LocalDateTime.now());
        carParkingRepository.save(carParkingDetail);
       return carParkingDetail;
    }

    public CarParkingDetail reallocateCarParking(String parkingSlotId, int parkingDurationInHours) {
        if(parkingDurationInHours<1 || parkingDurationInHours >4)
        {
            throw new InvalidParkingDurationException("Parking duration should be between 1-4 hours");
        }
        if(parkingSlotId == null)
        {
            throw new InvalidCarParkingSlotException("Slot id cannot be empty or null");
        }
        CarParkingDetail carParkingDetail = carParkingRepository.findById(parkingSlotId);
        carParkingDetail.setParkingDurationInHours(parkingDurationInHours);
        carParkingRepository.save(carParkingDetail);
        return carParkingDetail;
    }

    public boolean deallocateCarParking(String slotId) {
        if(slotId == null)
        {
            throw new InvalidCarParkingSlotException("Slot Id cannot be null or empty");
        }
        if(carParkingRepository.findById(slotId) != null)
        {
            carParkingRepository.deleteById(slotId);
            return true;
        }
        return false;
    }
}
