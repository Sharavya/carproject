package com.carpark.repository;

import com.carpark.entity.CarParkingDetail;

import java.util.LinkedHashSet;
import java.util.Set;

public class CarParkingRepository {

    Set<CarParkingDetail> carDetailsSet = new LinkedHashSet<CarParkingDetail>();
    public void save(CarParkingDetail carParkingDetail) {
        //carDetailsSet.add(carParkingDetail);
    }
    public CarParkingDetail findById(String carParkingSlotId) {
        /*for(CarParkingDetail carParkingDetailFromSet :carDetailsSet)
        {
            if(carParkingDetailFromSet.getSlotId().equals(carParkingSlotId))
                return carParkingDetailFromSet;
        }*/
        return null;
    }

    public void deleteById(String slotId) {
    }
}
