package com.carpark.entity;

public class CarParkingDetail {
}
