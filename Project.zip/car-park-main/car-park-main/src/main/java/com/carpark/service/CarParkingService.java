package com.carpark.service;

import com.carpark.entity.CarParkingDetail;
import com.carpark.model.CarParkingModel;

public class CarParkingService {
    public CarParkingDetail allocateCarParking(CarParkingModel carParkingModel) {
        return null;
    }
}
