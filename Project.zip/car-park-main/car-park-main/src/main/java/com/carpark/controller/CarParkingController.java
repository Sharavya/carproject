package com.carpark.controller;

import com.carpark.entity.CarParkingDetail;
import com.carpark.model.CarParkingModel;
import com.carpark.service.CarParkingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CarParkingController {

    CarParkingService carParkingService;

    @PostMapping("/carparkingslots")
    public ResponseEntity<?> allocateCarParking(@RequestBody CarParkingModel carParkingModel)
    {
        CarParkingDetail carParkingDetail = carParkingService.allocateCarParking(carParkingModel);
        return ResponseEntity.status(HttpStatus.CREATED).body(carParkingDetail);
    }
}
