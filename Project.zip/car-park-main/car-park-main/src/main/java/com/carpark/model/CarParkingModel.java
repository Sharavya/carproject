package com.carpark.model;

public class CarParkingModel {
    private String carNumber;
    private  int parkingDurationInHours;

    public CarParkingModel(String carNumber, int parkingDurationInHours) {
        this.carNumber = carNumber;
        this.parkingDurationInHours = parkingDurationInHours;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public int getParkingDurationInHours() {
        return parkingDurationInHours;
    }

    public void setParkingDurationInHours(int parkingDurationInHours) {
        this.parkingDurationInHours = parkingDurationInHours;
    }
}
