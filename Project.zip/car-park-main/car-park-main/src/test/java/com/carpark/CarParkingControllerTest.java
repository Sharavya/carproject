package com.carpark;

import com.carpark.controller.CarParkingController;
import com.carpark.entity.CarParkingDetail;
import com.carpark.exception.InvalidDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.service.CarParkingService;
import com.google.gson.Gson;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@WebMvcTest(CarParkingController.class)
public class CarParkingControllerTest {

    @MockBean
    CarParkingService carParkingService;

    @Autowired
    MockMvc mockMvc;

    /*@Before
    public void setUp()
    {
        mockMvc = MockMvcBuilders.standaloneSetup()
    }*/
    @Autowired
   Gson gson;

    private final String invalidDurationExceptionMessage = "Duration should be between 1-4 hours";
    @Test
    public void allocatecarParking_shouldThrowBadRequest_with_DurationLessThanOneException() throws Exception
    {
        //Required Request model
        String carNumber = "A110";
        int parkingDurationInHours = 0;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);
        String carParkingModelJsonString = gson.toJson(carParkingModel);

        //mock service layer
        when(carParkingService.allocateCarParking(carParkingModel)).thenThrow(new InvalidDurationException(invalidDurationExceptionMessage));

        mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
                .content(carParkingModelJsonString)
                .contentType(MediaType.APPLICATION_JSON))
               .andExpect(result -> assertEquals(invalidDurationExceptionMessage,result.getResolvedException()));
    }

    @Test
    public void allocateCarParking_shouldReturn_201Created_Successful() throws Exception
    {
        //required model
        String carNumber = "A110";
        int parkingDurationInHours = 2;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);
        String carParkingModelJsonString = gson.toJson(carParkingModel);
        //mock service layer
        when(carParkingService.allocateCarParking(carParkingModel)).thenReturn(new CarParkingDetail());
        mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
                .content(carParkingModelJsonString)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.carNumber").value(carParkingModel.getCarNumber()));
    }
}
