import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class Test {
    public static void main(String[] args) {
        System.out.println(LocalDateTime.now());
        System.out.println(new Date());
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-ddHH:mm:ss.sss");
        String strDate = formatter.format(date);
        System.out.println("Date Format with MM/dd/yyyy : "+strDate);
    }
}
