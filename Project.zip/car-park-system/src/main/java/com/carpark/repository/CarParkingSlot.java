package com.carpark.repository;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
public class CarParkingSlot {

    @Id
    private String carNumber;
    private String parkingSlodId;
    private int parkingDurationInHours;
    private LocalDateTime entryTime;

    public CarParkingSlot(String carNumber, int parkingDurationInHours, LocalDateTime entryTime) {
        this.carNumber = carNumber;
        this.parkingSlodId = UUID.randomUUID().toString();
        this.parkingDurationInHours = parkingDurationInHours;
        this.entryTime = entryTime;
    }

    public CarParkingSlot() {

    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getParkingSlodId() {
        return parkingSlodId;
    }

    public void setParkingSlodId(String parkingSlodId) {
        this.parkingSlodId = parkingSlodId;
    }

    public int getParkingDurationInHours() {
        return parkingDurationInHours;
    }

    public void setParkingDurationInHours(int parkingDurationInHours) {
        this.parkingDurationInHours = parkingDurationInHours;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    public void setEntryTime(LocalDateTime entryTime) {
        this.entryTime = entryTime;
    }
}
