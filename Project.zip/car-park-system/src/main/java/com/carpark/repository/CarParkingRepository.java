package com.carpark.repository;

import com.carpark.entity.CarParkingDetails;

public class CarParkingRepository  {

        public CarParkingDetails findById(String carParkingSlotId) {
            return null;
        }

        public void deleteById(String carParkingSlotId) {
        }
    }
