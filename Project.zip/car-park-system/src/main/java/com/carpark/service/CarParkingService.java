package com.carpark.service;

import com.carpark.exception.InvalidCarNumberException;
import com.carpark.exception.InvalidCarParkingSlotException;
import com.carpark.exception.InvalidParkingDurationException;
import com.carpark.exception.ParkingSlotIdNotFoundException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingRepository;
import com.carpark.repository.CarParkingSlot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;


public class CarParkingService {


    CarParkingRepository carParkingRepository;

    public CarParkingService(CarParkingRepository carParkingRepository) {
        this.carParkingRepository = carParkingRepository;
    }
  public CarParkingSlot allocateParking(CarParkingModel carParkingModel) {

      if(carParkingModel.getCarParkingDurationInHours() < 1 || carParkingModel.getCarParkingDurationInHours() > 4)
      {
          throw new InvalidParkingDurationException("Parking duration should be between 1-4 hours");
      }
      if(carParkingModel.getCarNumber()==null)
      {
          throw new InvalidCarNumberException("Please provide a valid car number. It cannot be empty or null.");
      }
      CarParkingSlot carParkingSlot = new CarParkingSlot(carParkingModel.getCarNumber(),
              carParkingModel.getCarParkingDurationInHours(), LocalDateTime.now());
      carParkingRepository.save(carParkingSlot);
      Optional<CarParkingSlot> carParkingSlotFromDb = carParkingRepository.findById(carParkingModel.getCarNumber());

      return carParkingSlotFromDb.get();
  }

    public CarParkingSlot requestReallocateSlot(String parkingSlotId, CarParkingModel carParkingModel) {
        if(carParkingModel.getCarParkingDurationInHours()<1 || carParkingModel.getCarParkingDurationInHours() >4)
        {
            throw new InvalidParkingDurationException("Parking duration should be between 1-4 hours");
        }
        if(carParkingModel.getCarNumber()==null)
        {
            throw new InvalidCarNumberException("Please provide a valid car number. It cannot be empty or null.");
        }
        Optional<CarParkingSlot> carParkingSlotFromDB = carParkingRepository.findById(parkingSlotId);
        CarParkingSlot carParkingSlot = null;
        if(carParkingSlotFromDB.isPresent())
        {
            carParkingSlot = carParkingSlotFromDB.get();
            carParkingSlot.setParkingDurationInHours(carParkingModel.getCarParkingDurationInHours());
            carParkingRepository.save(carParkingSlot);
        }
        else
            throw new ParkingSlotIdNotFoundException("Please provide a valid parking slot ID.");
        return carParkingSlot;
    }

    public boolean deallocateCarParking(String carParkingSlotId) {
        if(carParkingSlotId == null) {
            throw new InvalidCarParkingSlotException("Slot Id cannot be empty or null");
        }
        if(carParkingRepository.findById(carParkingSlotId) !=null)
        {
            carParkingRepository.deleteById(carParkingSlotId);
            return true;
        }
        return false;
    }
}
