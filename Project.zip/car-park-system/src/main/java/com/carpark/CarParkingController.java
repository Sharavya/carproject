package com.carpark;

import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingSlot;
import com.carpark.service.CarParkingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class CarParkingController {

    @Autowired
    CarParkingService carParkingService;

    @PostMapping("/carparkingslots")
    public ResponseEntity<?> allocateParking(@RequestBody CarParkingModel carParkingModel)
    {
        CarParkingSlot carParkingSlot = carParkingService.allocateParking(carParkingModel);
        return ResponseEntity.status(HttpStatus.CREATED).body(carParkingSlot);
    }

    @PutMapping("/carparkingslots/{parkingSlotId}")
    public ResponseEntity<?>  requestReallocateSlot(@PathVariable String parkingSlotId, @RequestBody CarParkingModel carParkingModel)
    {
        CarParkingSlot carParkingSlot = carParkingService.requestReallocateSlot(parkingSlotId,carParkingModel);
        return ResponseEntity.status(HttpStatus.OK).body(carParkingSlot);
    }

    @DeleteMapping("/carparkingslots/{parkingSlotId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public @ResponseBody  void deallocateParking(@PathVariable String parkingSlotId)
    {
        carParkingService.deallocateParking(parkingSlotId);
    }
}
