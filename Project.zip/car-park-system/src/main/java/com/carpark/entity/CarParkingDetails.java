package com.carpark.entity;

public class CarParkingDetails {


}