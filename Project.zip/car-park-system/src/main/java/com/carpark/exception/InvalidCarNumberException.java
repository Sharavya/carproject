package com.carpark.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidCarNumberException extends RuntimeException {
    public InvalidCarNumberException(String invalidCarDetailExceptionMessage) {
        super(invalidCarDetailExceptionMessage);
    }
}
