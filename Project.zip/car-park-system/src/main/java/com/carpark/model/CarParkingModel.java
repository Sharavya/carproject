package com.carpark.model;

public class CarParkingModel {
    private  String carNumber;
    private  int carParkingDurationInHours;

    public CarParkingModel() {
    }

    public CarParkingModel(String carNumber, int carParkingDurationInHours) {
        this.carNumber = carNumber;
        this.carParkingDurationInHours = carParkingDurationInHours;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public int getCarParkingDurationInHours() {
        return carParkingDurationInHours;
    }
}
