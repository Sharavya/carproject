package com.carpark.controller;

import com.carpark.CarParkingController;
import com.carpark.exception.InvalidCarNumberException;
import com.carpark.exception.InvalidParkingDurationException;
import com.carpark.exception.ParkingSlotIdNotFoundException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingSlot;
import com.carpark.service.CarParkingService;
import com.google.gson.Gson;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(CarParkingController.class)
public class CarParkingControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    CarParkingService carParkingService;

    @Autowired
    Gson gson;

    @BeforeEach
    void setUp()
    {
    }

    private final String invalidDurationExceptionMessage = "Duration should be in the range 1-4 hrs inclusive.";
    private final String invalidCarDetailExceptionMessage = "Please provide a valid car number. It cannot be empty or null.";
    private final String parkingSlotIdNotFoundMessage = "Please provide a valid parking slot ID.";
    @Test
    public void allocateParking_shouldThrowBadRequest_with_DurationLessThanOne_exception() throws Exception
    {
        //Required Request Model
        CarParkingModel carParkingModel = new CarParkingModel("HT101",0 );
        String carParkingDetailsJsonString = gson.toJson(carParkingModel);

        //This is to mock the service layer
        when(carParkingService.allocateParking(any(CarParkingModel.class))).thenThrow(new InvalidCarNumberException(invalidDurationExceptionMessage));

        mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
                .content(carParkingDetailsJsonString)
                .contentType(MediaType.APPLICATION_JSON)
        ).andExpect(mvcResult -> assertEquals(invalidDurationExceptionMessage, mvcResult.getResolvedException().getMessage()));
    }

    @Test
    public void allocateParking_shouldThrowBadRequest_with_InvalidCarNumber_exception() throws Exception {
        CarParkingModel carParkingModel = new CarParkingModel("", 2);
        String carParkingDetailsJsonString = gson.toJson(carParkingModel);

        when(carParkingService.allocateParking(any(CarParkingModel.class))).thenThrow(new InvalidCarNumberException(invalidCarDetailExceptionMessage));

        mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
                .content(carParkingDetailsJsonString)
                .contentType(MediaType.APPLICATION_JSON)
        ).andExpect(mvcResult -> assertEquals(invalidCarDetailExceptionMessage, mvcResult.getResolvedException().getMessage()));
    }
    @Test
    public void allocateParking_shouldReturn_201Created_successful() throws Exception {
        CarParkingModel carParkingModel = new CarParkingModel("H101", 2);
        String carParkingDetailsJsonString = gson.toJson(carParkingModel);

        when(carParkingService.allocateParking(any(CarParkingModel.class))).thenReturn(new CarParkingSlot("H101", 2, LocalDateTime.now()));

        mockMvc.perform(MockMvcRequestBuilders.post("/carparkingslots")
                        .content(carParkingDetailsJsonString)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.carNumber").value(carParkingModel.getCarNumber()));
    }
    @Test
    public void requestReallocateSlot_shouldThrowNotFound_with_InvalidParkingSlotId_exception() throws Exception {
        //Required Request Model
        CarParkingModel carParkingModel = new CarParkingModel("HT101",0 );
        String carParkingDetailsJsonString = gson.toJson(carParkingModel);

        //This is to mock the service layer.
        when(carParkingService.requestReallocateSlot(anyString(), any(CarParkingModel.class))).thenThrow(new ParkingSlotIdNotFoundException(parkingSlotIdNotFoundMessage));

        mockMvc.perform(MockMvcRequestBuilders.put("/carparkingslots/101")
                .content(carParkingDetailsJsonString)
                .contentType(MediaType.APPLICATION_JSON)
        ).andExpect(mvcResult -> assertEquals(parkingSlotIdNotFoundMessage, mvcResult.getResolvedException().getMessage()));
    }
    @Test
    public void requestReallocateSlot_shouldThrowBadRequest_with_DurationLessThanOne_exception() throws Exception {
        CarParkingModel carParkingModel = new CarParkingModel("HT101",0 );
        String carParkingDetailsJsonString = gson.toJson(carParkingModel);

        when(carParkingService.requestReallocateSlot(anyString(), any(CarParkingModel.class))).thenThrow(new InvalidParkingDurationException(invalidDurationExceptionMessage));

        mockMvc.perform(MockMvcRequestBuilders.put("/carparkingslots/101")
                .content(carParkingDetailsJsonString)
                .contentType(MediaType.APPLICATION_JSON)
        ).andExpect(mvcResult -> assertEquals(invalidDurationExceptionMessage, mvcResult.getResolvedException().getMessage()));
    }


    @Test
    public void requestReallocateSlot_shouldThrowBadRequest_with_InvalidCarNumber_exception() throws Exception {
        CarParkingModel carParkingDeatils = new CarParkingModel("",2);
        String carParkingDetailsJsonString = gson.toJson(carParkingDeatils);

        when(carParkingService.requestReallocateSlot(anyString(), any(CarParkingModel.class))).thenThrow(new InvalidCarNumberException(invalidCarDetailExceptionMessage));

        mockMvc.perform(MockMvcRequestBuilders.put("/carparkingslots/101")
                .content(carParkingDetailsJsonString)
                .contentType(MediaType.APPLICATION_JSON)
        ).andExpect(mvcResult -> assertEquals(invalidCarDetailExceptionMessage, mvcResult.getResolvedException().getMessage()));


    }

    @Test
    public void requestReallocateSlot_shouldReturn_200OK_successful() throws Exception {
        CarParkingModel carParkingModel = new CarParkingModel("H102",2 );
        String carParkingDetailsJsonString = gson.toJson(carParkingModel);

        when(carParkingService.requestReallocateSlot(anyString(), any(CarParkingModel.class))).thenReturn(new CarParkingSlot("A101", 2, LocalDateTime.now()));

        mockMvc.perform(MockMvcRequestBuilders.put("/carparkingslots/101")
                        .content(carParkingDetailsJsonString)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.carNumber").value(carParkingModel.getCarNumber()));

    }

    @Test
    public void deallocateParking_shouldReturn_NotFound_With_InvalidParkingSlotId_exception() throws Exception {
        doThrow(new ParkingSlotIdNotFoundException(parkingSlotIdNotFoundMessage)).when(carParkingService).deallocateParking(anyString());

        mockMvc.perform(MockMvcRequestBuilders.delete("/carparkingslots/0"))
                .andExpect(status().isNotFound())
                .andExpect(mvcResult -> assertEquals(parkingSlotIdNotFoundMessage, mvcResult.getResolvedException().getMessage()));

    }

    @Test
    public void deallocateParking_shouldReturn_204NoContent_Successful() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/carparkingslots/101"))
                .andExpect(status().isNoContent());
    }

}
