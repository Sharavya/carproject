package com.carpark.repository;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CarParkingSlotTest {

    @Test
    public void equalityTest()
    {
        String carNumber = "KA-123";
        int parkingDurationInHours = 2;
        LocalDateTime entryTime = LocalDateTime.now();

        CarParkingSlot carParkingSlotA = new CarParkingSlot(carNumber, parkingDurationInHours,entryTime);
        CarParkingSlot carParkingSlotB = new CarParkingSlot(carNumber, parkingDurationInHours,entryTime);

        assertEquals(carParkingSlotA, carParkingSlotB);

    }
}
