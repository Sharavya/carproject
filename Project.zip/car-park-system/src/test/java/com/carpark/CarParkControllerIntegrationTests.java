package com.carpark;

import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingSlot;
import com.carpark.repository.CarParkingSlotTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CarParkControllerIntegrationTests {

	@Test
	void contextLoads() {
	}

	@Autowired
	TestRestTemplate restTemplate;

	@Test
	public void requestCarParkingSlot_returnCarParkigSlot() throws Exception
	{
		CarParkingModel carParkingModel = new CarParkingModel("KA-123",3);
		ResponseEntity<CarParkingSlot> response = restTemplate.postForEntity("/carparking/carparkingslots",
				carParkingModel, CarParkingSlot.class);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getCarNumber()).isEqualTo("KA-123");
		assertThat(response.getBody().getParkingDurationInHours()).isEqualTo(3);
	}

	@Test
	public void requestReallocateSlot_returnsReallotedSlot() throws Exception
	{
		restTemplate.put("/carparking/carparkingslots/436f7d85-988f-417d-99ff-47b12ced6cd8/3", CarParkingSlotTest.class);

	}
	@Test
	public void exitParking_deletesCarParkinSlot() throws Exception
	{
		restTemplate.delete("/carparking/carparkingslots/436f7d85-988f-417d-99ff-47b12ced6cd8");

	}
}
