package com.carpark.service;

import com.carpark.entity.CarParkingDetails;
import com.carpark.exception.InvalidCarParkingSlotException;
import com.carpark.exception.InvalidParkingDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingRepository;
import com.carpark.repository.CarParkingSlot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CarParkingServiceTest {

    @Mock
    CarParkingRepository carParkingRepository;

    CarParkingService carParkingService;

    @BeforeEach
    public void setUp()
    {
        carParkingService = new CarParkingService(carParkingRepository);
    }

    @Test
    public void carParking_bookingSuccesful()
    {
        String carNumber = "KA-123";
        int parkingDurationInHours = 2;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber, parkingDurationInHours);
        CarParkingSlot parkingSlot = carParkingService.allocateParking(carParkingModel);

        assertEquals(carNumber, parkingSlot.getCarNumber());
    }

    @Test
    public void carParking_durationLessThanOne_exception()
    {
        String carNumber = "KA-123";
        int parkingDurationInHours = 0;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);
        assertThrows(InvalidParkingDurationException.class, ()->
        {
            carParkingService.allocateParking(carParkingModel);
        });
    }

    @Test
    public void carParking_parkingDurationGreaterThanFour_exception()
    {
        String carNumber = "KA-123";
        int parkingDurationInHours = 5;
        CarParkingModel carParkingModel = new CarParkingModel(carNumber,parkingDurationInHours);

        assertThrows(InvalidParkingDurationException.class, ()->
        {
            carParkingService.allocateParking(carParkingModel);
        });
    }

    @Test
    public void carParking_reallocateSuccessful()
    {
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 2;
        CarParkingModel carParkingModel = new CarParkingModel(parkingSlotId,parkingDurationInHours);
        CarParkingSlot carParkingSlot = carParkingService.requestReallocateSlot(parkingSlotId,carParkingModel);

        assertEquals(parkingDurationInHours,carParkingSlot.getParkingDurationInHours());
    }

    @Test
    public void carParking_reallocateParkingDurationGreaterThanFour_exception()
    {
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 5;
        CarParkingModel carParkingModel = new CarParkingModel(parkingSlotId,parkingDurationInHours);

        assertThrows(InvalidParkingDurationException.class, ()->
        {
            carParkingService.requestReallocateSlot(parkingSlotId,carParkingModel);
        });
    }

    @Test
    public void carParking_reallocateDurationLessThanOne_exception()
    {
        String parkingSlotId = "436f7d85-988f-417d-99ff-47b12ced6cd8";
        int parkingDurationInHours = 0;
        CarParkingModel carParkingModel = new CarParkingModel(parkingSlotId,parkingDurationInHours);

        assertThrows(InvalidParkingDurationException.class, ()->
        {
            carParkingService.requestReallocateSlot(parkingSlotId,carParkingModel);
        });
    }
    @Test
    public void deallocateCarParking_throwsInvalidCarParkingSlotId()
    {
        //act
        String carParkingSlotId = null;
        //assign
        Exception exception = assertThrows(InvalidCarParkingSlotException.class, ()-> carParkingService.deallocateCarParking(carParkingSlotId));
        //assert
        assertEquals(exception.getMessage(),"Slot Id cannot be empty or null");
    }

    @Test
    public void deallocateCarParking_successful()
    {
        String carParkingSlotId = "123";
        when(carParkingRepository.findById(carParkingSlotId)).thenReturn(new CarParkingDetails());

        assertEquals(carParkingService.deallocateCarParking(carParkingSlotId),true);

    }
}
